#include "hardware.h"
/**********************UART1 ISR***********************************************/
void USART1_RX_ISR() iv IVT_INT_USART1 ics ICS_AUTO{
     DisableInterrupts();
     BLUE_LED = 1;
     GREEN_LED = 0;
     rx_flag = 1;
     if(UART1_Data_Ready())
     {
        UART1_Read_Text(receive, "~", 1000);
     }
     EnableInterrupts();
}
/******************************************************************************/

void main() {
     setup();
     UART2_Write_Text("System Ready");   //
     UART2_Write(13);                    //For New Line
     UART2_Write(10);                    //
     manchester_encoding('Z');
     default_send = me_byte2;
     GREEN_LED = 1;
     while(1)
     { 
       UART2_Write(default_send);       //Send Default Manchester Encoded Character Continuously
       if (rx_flag)                     //Check that is string is captured through UART1
       {
              counter1 = 0;
              /*************Encoding Received String into Manchester*************/
              for ( counter = 0; counter < strlen(receive); counter++)
              {
                  manchester_encoding(receive[counter]);
                  receive_me[counter1++] = me_byte2;
                  receive_me[counter1++] = me_byte1;
              }
              /****************************************************************/
             
             UART2_Write(0xAA);                  //Sending Start Byte
             UART2_Write_Text(receive_me);       //Sending Encoded String
             UART2_Write('&');                   //Sending Stop Byte
             //Delay_ms(2);
             Delay_us(1000);
             memset(receive, '\0',strlen(receive));  //Clear Receive Buffer
             memset(receive_me, '\0',strlen(receive_me)); //Clear Encoding Buffer
       }
        rx_flag = 0;            //Clear flag for receiving string from UART 1
        BLUE_LED = 0;
        GREEN_LED = 1;
     }
}