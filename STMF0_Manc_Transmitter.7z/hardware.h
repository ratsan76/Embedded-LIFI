#include "_8b10b.h"
#include "manchester.h"
sbit GREEN_LED at GPIOC_ODR.B9;
sbit BLUE_LED at GPIOC_ODR.B8;
char receive[1000];
char receive_me[2000];
char receive_de[1000];
char buffer[1000]= "a";
int counter, counter1;
char to_decode_bytes[2];
char default_send;
char rx_flag = 0;
char test[] = "";
char rx_byte;
/**********************Initialise all protocols and gpios**********************/
void setup()
{
    GPIO_Digital_Output(&GPIOC_ODR, _GPIO_PINMASK_8 | _GPIO_PINMASK_9 );
    /******************Initialise UART1 with RX interrupt***************/
    UART1_Init_Advanced(1000000, _UART_8_BIT_DATA, _UART_NOPARITY, _UART_ONE_STOPBIT, &_GPIO_MODULE_USART1_PA9_10);
    USART1_CR1bits.RXNEIE = 1;
    NVIC_IntEnable(IVT_INT_USART1);
    EnableInterrupts();
    /******************************************************************/
    UART2_Init(1000000);
}
/******************************************************************************/

/************************Convert received buffer into LIFI Format**************/
void lifi_format()
{
   strcpy(buffer, "start");
   strcat(buffer, receive);
   strcat(buffer, "stop");
}
/******************************************************************************/


/*******************************Main Working Function**************************/
void working()
{
     if(UART1_Data_Ready())
     {
        GPIOC_ODR.B8 = 0;
        GPIOC_ODR.B9 = 1;
        UART1_Read_Text(receive, "~", 1000);
        counter1 = 0;
        for ( counter = 0; counter < strlen(receive); counter++)
        {
            manchester_encoding(receive[counter]);
            receive_me[counter1++] = me_byte2;
            receive_me[counter1++] = me_byte1;
        }
        UART1_Write_Text("String After encoding : ");
        UART1_Write_Text(receive_me);
        Delay_ms(100);
        //strcpy(buffer, receive_me);
        UART2_Write('a');
        UART2_Write_Text(receive_me);
        UART2_Write_Text("~");
        UART2_Write(13);
        UART2_Write(10);
        counter = 0;
        counter1 = 0;
        do
        {
         to_decode_bytes[1] = receive_me[counter++];
         to_decode_bytes[0] = receive_me[counter++];
         receive_de[counter1++] = manchester_decoding(to_decode_bytes);
        }while(counter < strlen(receive_me));
        UART1_Write(13);
        UART1_Write(10);
        UART1_Write_Text("String After Decoding : ");
        UART1_Write_Text(receive_de);
        memset(receive_me, '\0', sizeof(receive_me));
        memset(receive_de, '\0', sizeof(receive_de));
        memset(receive, '\0', sizeof(receive));
        UART1_Write(13);
        UART1_Write(10);
        Delay_ms(250);
     }
     counter1 = 0;
     counter = 0;
}
/******************************************************************************/