#include "hardware.h"
sbit GREEN_LED at GPIOC_ODR.B9;
sbit BLUE_LED at GPIOC_ODR.B8;
sbit pin at GPIOB_ODR.B0;
char count;
char flag, flag1 = 0;
char test;

/******************Interrupt Service Routine************************************/
//Capture Data at USART 1 receives from photodetector
//Capture data in receive string after start bit receives "0xAA"
//Stops capturing data after stop bit that is "&"
void USART1_RX_interrupt() iv IVT_INT_USART1 ics ICS_AUTO{
      test = UART1_Read();
      if(flag == 1)
      {
       receive[counter++] = test;
       if(test == '&')
         {
          flag1 = 1;
         }

      }
      if (test == 0XAA)
      {
         flag = 1;
      }
}
void main() {
     setup();
     UART1_Write_Text("System Ready");
     UART1_Write(13);
     UART1_Write(10);
     GREEN_LED = 1;
     counter = 0;
    while(1)
     {
      if ( flag1 == 1)  //flag1 is high when receive string completely captured
      {
          flag = 0;
          flag1 = 0;
          BLUE_LED = 1;
          counter = 0;
          counter1 = 0;
          memmove(receive_me, receive_me+1, strlen(receive_me));
         /***************Manchester Decoding***********************************/
          do
          {
           to_decode_bytes[1] = receive[counter++];
           to_decode_bytes[0] = receive[counter++];
           receive_de[counter1++] = manchester_decoding(to_decode_bytes);
          }while(counter < strlen(receive));
         /**********************************************************************/
          receive_de[strlen(receive_de) -1 ] = '\0';
          UART2_Write_Text(receive_de);
          UART2_Write(13);
          UART2_Write(10);
          memset(receive_de, '\0', sizeof(receive_de));//Clear receiving buffer
          memset(receive, '\0', sizeof(receive));      //Clear receiving buffer for capturing next data
          counter = 0;
      }
       BLUE_LED = 0;
     }
}