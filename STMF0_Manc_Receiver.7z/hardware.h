#include "_8b10b.h"
#include "manchester.h"
char receive[1000] = "";
char receive_me[2000] = "";
char receive_de[1000] = "";
char buffer[1000];
char default_data[] = "LIFI Testing at the Velmenni LAB using STM32F4 \
Disocvery Boards";
int counter, counter1;
int receive_me_length;
char to_decode_bytes[2];
int i = 0;

/**********************Initialise all protocols and gpios**********************/
void setup()
{
    GPIO_Clk_Enable(&GPIOC_BASE);
    UART1_Init(115200);
    Delay_ms(100);
    UART2_Init(115200);
    Delay_ms(100);
}
/******************************************************************************/

/************************Convert received buffer into LIFI Format**************/
void lifi_format()
{
  // strcpy(buffer, "start");
  // strcat(buffer, receive);
  // strcat(buffer, "stop");
}
/******************************************************************************/


/*******************************Main Working Function**************************/
void working()
{

/*if (UART1_Data_Ready())
     {    GPIOG_ODR.B13  = 1;
          UART1_Read_Text(receive, "ok", 1000);  //Receive data upto "ok string"
                                                 //length of received data is upto 1000 bytes
          lifi_format();
          _8b10b_encoding();             //Use this if 8b10b has to be used
          // manchester_encoding();         //Use this if manchester has to be used
          UART6_Write_Text(buffer);
          //UART6_Write_Text(transmit);
          //UART6_Write(13);
          //UART6_Write(10);
          GPIOG_ODR.B13  = 0;
          Delay_ms(1000);
     }
     memset(buffer, '\0', sizeof(buffer));
     memset(receive, '\0', sizeof(buffer));*/
     /*UART6_Write_Text("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
     UART6_Write(13);
     UART6_Write(10);*/

     if(UART2_Data_Ready())
     {
        UART2_Read_Text(receive, "~", 1000);
        counter1 = 0;
       /* for ( counter = 0; counter < strlen(receive); counter++)
        {
            manchester_encoding(receive[counter]);
            receive_me[counter1++] = me_byte2;
            receive_me[counter1++] = me_byte1;
        } */
        Delay_ms(100);
        UART1_Write_Text("Encoded string : ");
        UART1_Write_Text(receive);
        //UART6_Write_Text(receive);
        //UART6_Write_Text("~");
        UART1_Write(13);
        UART1_Write(10);
        //receive_me_length = strlen(receive_me);

        //itoa(receive_me_length, hello);

        /*switch (i)
        {
         case 1: strcpy(receive_me,"��������");
                 break;
         case 2: strcpy(receive_me,"�j���Z�Z�U�����U���Z��");
                 break;
         case 3: strcpy(receive_me,"���j�i�����i�������������i�V�����U�����Y���V���j���������������V���U���i�V������������");
                 break;
         case 4: strcpy(receive_me,"�����Z�Y���V�V�i�����������i�V��");
                 break;
         case 5: strcpy(receive_me,"��������");
                 break;
         case 6: strcpy(receive_me,"��������");
                 break;
         default:
                 break;
        }*/
        Delay_ms(100);
        strcpy(receive_me, receive);
        //Delay_ms(100);
        counter = 0;
        counter1 = 0;
        do
        {
         to_decode_bytes[1] = receive_me[counter++];
         to_decode_bytes[0] = receive_me[counter++];
         receive_de[counter1++] = manchester_decoding(to_decode_bytes);
        }while(counter < strlen(receive_me));
        memmove(receive_de, receive_de+1, strlen(receive_de));
        UART1_Write_Text("String After Decoding : ");
        UART1_Write_Text(receive_de);
        memset(receive_me, '\0', sizeof(receive_me));
        memset(receive_de, '\0', sizeof(receive_de));
        memset(receive, '\0', sizeof(receive));
        memset(to_decode_bytes, '\0', sizeof(to_decode_bytes));
        UART1_Write(13);
        UART1_Write(10);
        //Delay_ms(250);
     }
     counter1 = 0;
     counter = 0;
     if ( i < 6)
        i++;
     else
         i = 0;
}
/******************************************************************************/