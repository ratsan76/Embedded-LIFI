int me_byte1, me_byte2;
char nibbler(char);
/*************************Manchester Encoding Function******************************/
void manchester_encoding(char byt)
{
    int i,j,b,me;
    b = byt;
    for (i=0; i<2; i++) {
        me = 0;         // manchester encoded txbyte
        for (j=0 ; j<4; j++) {
            me >>=2;
            if ((b&(1))!=0 )
               {
                me |= 0b01000000; // 1->0
                }
            else
               {
                me |= 0b10000000; // 0->1
                }
            b >>=1;
        }
        if ( i == 0)
           me_byte1 = me;
        else
           me_byte2 = me;
    }
}
/******************************************************************************/

/************************Manchester Decoding Function*******************************/
char manchester_decoding(char recieved[2])
{
   return((nibbler(recieved[1])*16)^(nibbler(recieved[0])));
}
/******************************************************************************/

char nibbler(char encoded)
{
        char i,dec,enc,pattern;
        enc = encoded;
        if (enc == 0xF0)
        return 0xf0;
        dec = 0;
        for(i = 0; i<4; i++)
        {
        dec >>=1;
        pattern = enc & 0x03;
        if (pattern == 0x01)
        dec |= (1<<3);
        else if(pattern == 0x02)
        dec &= ~(1<<3);
        else
        return 0xff;
        enc >>=2;
        }
        return dec;
}